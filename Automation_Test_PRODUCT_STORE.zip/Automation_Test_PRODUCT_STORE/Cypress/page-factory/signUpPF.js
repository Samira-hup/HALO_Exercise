/// <reference types="Cypress" />

import SignUpPOM from '../page-object-model/signUpPOM'

class SignUpPF {
    
    SignUpNewUser() {

        cy.intercept('POST', 'https://api.demoblaze.com/signup').as('SigUp')
        SignUpPOM.SignUpIconModal().click()
        SignUpPOM.SignUpUsername().should('be.visible').clear().type(`Automation${Math.floor(Math.random() * 100000) + 50}`)
        SignUpPOM.SignUpPassword().should('be.visible').clear().type('Automated123')
        SignUpPOM.SignUpBtn().click()

        cy.wait('@SigUp').then((interception) => {
            expect(interception.response.body).to.not.have.property('errorMessage');
        });
    }

    SignUpExistUser() {

        cy.intercept('POST', 'https://api.demoblaze.com/signup').as('SigUpExist')
        SignUpPOM.SignUpIconModal().click()
        SignUpPOM.SignUpUsername().should('be.visible').clear().type('Automated')
        SignUpPOM.SignUpPassword().should('be.visible').clear().type('Automated123')
        SignUpPOM.SignUpBtn().click()

        cy.wait('@SigUpExist').then((interception) => {
            expect(interception.response.body).to.have.property('errorMessage', 'This user already exist.');
          });

        cy.clearCookies()
        cy.handleAlert('This user already exist.');
    }
  }

  
  export default new SignUpPF();
  