/// <reference types="Cypress" />

class HomePagePF {
    
    visit() {
      cy.visit('https://www.demoblaze.com/')
    }
  }
  
  export default new HomePagePF();
  