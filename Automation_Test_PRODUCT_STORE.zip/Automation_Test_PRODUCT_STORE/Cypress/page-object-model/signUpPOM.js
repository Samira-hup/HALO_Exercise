/// <reference types="Cypress" />

class SignUpPOM {

    SignUpIconModal() {
        return cy.get('#signin2')
    }
    
    SignUpUsername() {
        return cy.get('#sign-username')
    }

    SignUpPassword() {
        return cy.get('#sign-password')
    }

    SignUpBtn() {
        return cy.get('#signInModal').find('.btn-primary')
    }
    

  }
  
  export default new SignUpPOM();
  