/// <reference types="Cypress" />

class cartPOM {

    GetCartItem() {
        return cy.get('.col-lg-8').find('#tbodyid > tr')
    }

    GetPlaceOrderBtn() {
        return cy.get('.btn-success').contains('Place Order')
    }

    getNameInput() {
        return cy.get('#name')
    }

    getCountryInput() {
        return cy.get('#country')
    }

    getCityInput() {
        return cy.get('#city')
    }

    getCreditCardInput() {
        return cy.get('#card')
    }

    getMonthInput() {
        return cy.get('#month')
    }

    getYearInput() {
        return cy.get('#year')
    }

    getPurchaseBtn() {
        return cy.get('.btn-primary').contains('Purchase')
    }

    getTotalAmmount() {
        return cy.get('#totalm')
    }
    
}

export default new cartPOM();
  