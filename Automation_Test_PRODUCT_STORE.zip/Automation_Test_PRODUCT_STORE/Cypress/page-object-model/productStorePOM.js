/// <reference types="Cypress" />

class ProductStorePOM {

    GetToCategory(cat) {
        return cy.get('.list-group').contains(cat)
    }

    GetTotalProduct() {
        return cy.get('.col-lg-9').find('#tbodyid > div').find('img')
    }

    GetaddToCartBtn() {
        return cy.get('.btn-lg')
    }
    

}

export default new ProductStorePOM();
  