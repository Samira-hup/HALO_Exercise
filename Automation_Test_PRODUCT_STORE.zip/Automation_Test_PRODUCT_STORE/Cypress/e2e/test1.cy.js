/// <reference types="Cypress" />

// import Poms and Page Factory 
import HomePage from '../page-factory/homePagePF';
import SignUpPF from '../page-factory/signUpPF';
import LoginPF from '../page-factory/loginPF';
import productStorePF from '../page-factory/productStorePF';
import cartPF from '../page-factory/cartPF'

describe('Automation Test PRODUCT STORE', () => {

  beforeEach(() => {

    // this is to wait until the elements appears
    cy.intercept('GET', 'https://api.demoblaze.com/entries').as('entries')
    cy.intercept('GET', 'https://hls.demoblaze.com/index.m3u8').as('index')
    HomePage.visit()
    cy.wait('@entries')
    cy.wait('@index') 
  });

  // Scenario #1: ................................................................................

  // Go to https://www.demoblaze.com/
  // Sign Up as a new user
  // Validate if you try signup with same user modal will appear 
  // Log in
  // Log out
  // Try logging in with invalid user 

  it.only('Test 1: Login and Sign up test', () => {
    SignUpPF.SignUpNewUser()
    //SignUpPF.SignUpExistUser()
    LoginPF.LoginWithExistUser('AutomationSamira', 'Samira123')
    LoginPF.Logout()
    LoginPF.LoginWithInvalidUser('aasbuyfbasuyfbasub', 'sabudfabsufasbu')

    cy.log('Test #1 SUCCESS!')

  });

  // Scenario #2: ................................................................................
  
  // Log in
  // Go to Phones
  // Click on Any phone
  // Add to cart
  // Go to another phone and add it to cart
  // Go to cart and remove one item
  // Place order and populate modal

  it.only('Test 2: Login, add 2 phones to cart, remove 1 and pay', () => {
    cy.wait(1000)
    LoginPF.LoginWithExistUser('AutomationSamira', 'Samira123')
    productStorePF.GoToCategory('Phone')
    productStorePF.AddProductToCart(1)
    HomePage.visit()
    productStorePF.GoToCategory('Phone')
    productStorePF.AddProductToCart(2)
    cartPF.Visit()
    cartPF.RemoveItem(1)
    cartPF.PlaceOrder()
    cartPF.FillPlaceOrderFields()
    cartPF.PurchaseOrder()

    cy.log('Test #2 SUCCESS!')

  });

    
  // Scenario #3: ................................................................................
  
  // Log in
  // Go to Phones
  // Click on Any phone
  // Add to cart
  // Go to another phone and add it to cart
  // Go to cart and remove one item
  // Place order and populate modal
  // Validate charged information is correct as well as other info in confirmation popup
  
  it.only('Test 3: Validate Order Details', () => {
    cy.wait(1000)
    LoginPF.LoginWithExistUser('AutomationSamira', 'Samira123')
    productStorePF.GoToCategory('Laptops')
    productStorePF.AddProductToCart(1)
    HomePage.visit()
    productStorePF.GoToCategory('Phone')
    productStorePF.AddProductToCart(2)
    cartPF.Visit()
    cartPF.RemoveItem(1)
    cartPF.PlaceOrder()
    cartPF.FillPlaceOrderFields()
    cartPF.PurchaseOrder()
    cartPF.ValidateOrderDetails()

    cy.log('Test #3 SUCCESS!')
  });


});

